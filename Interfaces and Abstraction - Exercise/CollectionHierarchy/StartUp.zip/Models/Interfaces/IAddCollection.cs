﻿
namespace CollectionHierarchy.Models.Interfaces;

public interface IAddCollection
{
    int Add(string item);
}
