﻿
namespace CollectionHierarchy.Models.Interfaces;

public interface IAddRemoveCollection : IAddCollection
{
    string Remove();
}
