﻿namespace MilitaryElite.Enums;

public enum MissionStates
{
    inProgress,
    Finished
}
