﻿using MilitaryElite.Enums;
using MilitaryElite.Models.Interfaces;

namespace MilitaryElite.Models;

public class Mission : IMission
{
    public Mission(string codeName, MissionStates state)
    {
        CodeName = codeName;
        State = state;
    }

    public string CodeName { get; private set; }

    public MissionStates State { get; private set; }

    public void CompleteMission()
    {
        State = MissionStates.Finished;
    }

    public override string ToString()
    {
        return $"Code Name: {CodeName} State: {State}";
    }
}
